<!DOCTYPE html>
<html dir="ltr" lang="en-us">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />

<title>Scarleteen Boards - Index page</title>

	<link rel="alternate" type="application/atom+xml" title="Feed - Scarleteen Boards" href="https://www.scarleteen.com/bb/feed.php">	<link rel="alternate" type="application/atom+xml" title="Feed - News" href="https://www.scarleteen.com/bb/feed.php?mode=news">	<link rel="alternate" type="application/atom+xml" title="Feed - All forums" href="https://www.scarleteen.com/bb/feed.php?mode=forums">	<link rel="alternate" type="application/atom+xml" title="Feed - New Topics" href="https://www.scarleteen.com/bb/feed.php?mode=topics">	<link rel="alternate" type="application/atom+xml" title="Feed - Active Topics" href="https://www.scarleteen.com/bb/feed.php?mode=topics_active">			

<!--
	phpBB style name: prosilver
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:
-->

<script>
	WebFontConfig = {
		google: {
			families: ['Open+Sans:600:cyrillic-ext,latin,greek-ext,greek,vietnamese,latin-ext,cyrillic']
		}
	};

	(function(d) {
		var wf = d.createElement('script'), s = d.scripts[0];
		wf.src = 'https://ajax.googleapis.com/ajax/libs/webfont/1.5.18/webfont.js';
		wf.async = true;
		s.parentNode.insertBefore(wf, s);
	})(document);
</script>
<link href="./styles/scarleteen/theme/stylesheet.css?assets_version=21" rel="stylesheet">
<link href="./styles/scarleteen/theme/en_us/stylesheet.css?assets_version=21" rel="stylesheet">
<link href="./styles/scarleteen/theme/responsive.css?assets_version=21" rel="stylesheet" media="all and (max-width: 700px), all and (max-device-width: 700px)">



<!--[if lte IE 9]>
	<link href="./styles/scarleteen/theme/tweaks.css?assets_version=21" rel="stylesheet">
<![endif]-->

<meta name="google-site-verification" content="" />

<link href="./ext/hifikabin/googlesearch/styles/prosilver/theme/googlesearch.css?assets_version=21" rel="stylesheet" type="text/css" media="screen" />



</head>
<body id="phpbb" class="nojs notouch section-index ltr ">


<div id="wrap">
	<a id="top" class="anchor" accesskey="t"></a>

	<div id="main-header">
		
    <header id="navbar" role="banner" class="navbar container-fluid navbar-default">
  <div class="navbar-container container-fluid">

    <div class="navbar-header">
              <a class="logo navbar-btn" href="/" title="Home">

        </a>
      
          </div>

    <div class="header-donation">
      <a href="https://npo.networkforgood.org/Donate/Donate.aspx?npoSubscriptionId=1005181&amp;code=STPRIMARY"><img alt="Donate Here" src="/sites/all/themes/scarleteen/images/donation.png" title="Donate Now - help keep the best sex ed online free and also fabulous"></a>
    </div>

          <div id="yellow-bar">
        <div class="region region-navigation">
    <section id="block-search-form" class="block block-search clearfix"

>

      
  <div class="block-content">
    <form class="google-cse form-search content-search" action="./search.php" method="get" id="search-block-form" accept-charset="UTF-8"><div><div>
      <h2 class="element-invisible">Search form</h2>
    <div class="input-group"><input title="Enter the terms you wish to search for." placeholder="search boards" class="form-control form-text" type="text" id="edit-search-block-form--2" name="keywords" value="" size="15" maxlength="128" /><span class="input-group-btn"><button type="submit" class="btn btn-primary">Search</button></span></div><div class="form-actions form-wrapper form-group" id="edit-actions"><button class="element-invisible btn btn-primary form-submit" type="submit" id="edit-submit" name="op" value="Search">Search</button>
</div><input type="hidden" name="form_build_id" value="form-tJgvVEdl-OVzuPUgrrmwkafUsid9q5pggNzVyQX2cck" />
<input type="hidden" name="form_id" value="keywords" />
</div>
</div></form>  </div>

</section>
<section id="block-block-49" class="block block-block block-social clearfix"

>

      
  <div class="block-content">
     <p><a href="http://www.scarleteen.com/rss.xml" target="_blank"><img alt="RSS" src="/sites/all/themes/scarleteen/images/rss.png" style="height:24px; width:24px" title="RSS" /></a><a href="http://twitter.com/Scarleteen" target="_blank"><img alt="Twitter" src="/sites/all/themes/scarleteen/images/twitter.png" style="height:24px; width:24px" title="Twitter" /></a><a href="https://www.instagram.com/scarleteenorg/"><img alt="Instagram" src="https://www.scarleteen.com/sites/files/scarleteen/instagram.png" style="width: 24px; height: 24px;" /></a><a href="http://hellyeahscarleteen.tumblr.com/" target="_blank"><img alt="Tumblr" src="/sites/all/themes/scarleteen/images/tumblr.png" style="height:24px; width:24px" title="Tumblr" /></a><a href="http://www.facebook.com/pages/Scarleteen/15025045594" target="_blank"><img alt="Facebook" src="/sites/all/themes/scarleteen/images/facebook.png" style="height:24px; width:24px" title="Facebook" /></a></p>
   </div>

</section>
<section id="block-block-48" class="block block-block block-link clearfix"

>

      
  <div class="block-content">
     <p><a href="/the_scarleteen_tour_bus_a_quick_how_to" style="font-weight: bold; margin-right: 5px">new here?</a></p>
   </div>

</section>
<section id="block-block-34" class="block block-block block-link clearfix"

>

      
  <div class="block-content">
     <p><a class="textonly-link" href="?theme=scarleteen_textonly">text-only</a></p>
   </div>

</section>
  </div>
      </div>
    
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
    
    <div class="navbar-collapse collapse">
      <nav class="primary-nav" role="navigation">
                  <span class="goto">GO TO:</span> <ul class="menu nav navbar-nav"><li class="first leaf" id="menu-bodies"><a href="/article/bodies">bodies</a></li>
<li class="leaf" id="menu-gender"><a href="/article/gender" title="">gender</a></li>
<li class="leaf" id="menu-sexual-identity"><a href="/article/sexual-identity" title="">sexual identity</a></li>
<li class="leaf" id="menu-relationships"><a href="/article/relationships" title="">relationships</a></li>
<li class="leaf" id="menu-sexuality"><a href="/article/sexuality" title="">sex &amp; sexuality</a></li>
<li class="leaf" id="menu-sexual-health"><a href="/article/sexual-health" title="">sexual health</a></li>
<li class="leaf" id="menu-pregnancy-and-parenting"><a href="/article/pregnancy-and-parenting">pregnancy &amp; parenting</a></li>
<li class="leaf" id="menu-abuse-and-assault"><a href="/article/abuse-and-assault">abuse</a></li>
<li class="leaf" id="menu-disability"><a href="/article/disability">disability</a></li>
<li class="leaf" id="menu-politics"><a href="/article/politics">sexual politics</a></li>
<li class="leaf" id="menu-advice"><a href="/article/advice">advice</a></li>
<li class="leaf" id="menu-quickies"><a href="/article/quickies">quickies</a></li>
<li class="last leaf" id="menu-etc"><a href="/article/etc">etc</a></li>
</ul>              </nav>
      <nav class="secondary-nav" role="navigation">
                  <span class="goto">ask for help:</span> <ul class="menu nav navbar-nav secondary"><li class="first leaf" id="menu-bb"><a href="http://www.scarleteen.com/bb/" title="">message boards</a></li>
<li class="leaf" id="menu-7934"><a href="/our_live_chat_service" title="">live chat</a></li>
<li class="last leaf" id="menu-2739"><a href="/text_scarleteen" title="">sms/text</a></li>
</ul>              </nav>
    </div>

        <aside id="content-top">
        <div class="region region-header">
    <section id="block-block-50" class="block block-block clearfix">

          <h2 class="block-title">lookie here:</h2>
  
  <div class="block-content">
     <p><a href="https://www.scarleteen.com/blog/heather_corinna/wait_what_its_finally_here_it_is">Check out our new comic for pre-teens!</a></p>
   </div>

</section>
  </div>
    </aside> <!-- /#page-header -->
      </div>
</header>
  
	</div>

	<div id="page-header">
				<div class="navbar" role="navigation">
	<div class="inner">

	<ul id="nav-main" class="linklist bulletin" role="menubar">

		<li id="quick-links" class="small-icon responsive-menu dropdown-container" data-skip-responsive="true">
			<a href="#" class="responsive-menu-link dropdown-trigger">Quick links</a>
			<div class="dropdown hidden">
				<div class="pointer"><div class="pointer-inner"></div></div>
				<ul class="dropdown-contents" role="menu">
					
											<li class="separator"></li>
																		 
							<li class="small-icon icon-search-unread"><a href="./search.php?search_id=unreadposts" role="menuitem">Unread posts</a></li>
												<li class="small-icon icon-search-unanswered"><a href="./search.php?search_id=unanswered" role="menuitem">Unanswered posts</a></li>
						<li class="small-icon icon-search-active"><a href="./search.php?search_id=active_topics" role="menuitem">Active topics</a></li>
						<li class="separator"></li>
						<li class="small-icon icon-search"><a href="./search.php" role="menuitem">Search</a></li>
					
											<li class="separator"></li>
												<li class="small-icon icon-team"><a href="./memberlist.php?mode=team" role="menuitem">The team</a></li>										<li class="separator"></li>

									</ul>
			</div>
		</li>

				<li class="small-icon icon-faq" data-skip-responsive="true"><a href="./faq.php" rel="help" title="Frequently Asked Questions" role="menuitem">FAQ</a></li>
						
			<li class="small-icon icon-logout rightside"  data-skip-responsive="true"><a href="./ucp.php?mode=login" title="Login" accesskey="x" role="menuitem">Login</a></li>
					<li class="small-icon icon-register rightside" data-skip-responsive="true"><a href="./ucp.php?mode=register" role="menuitem">Register</a></li>
						</ul>

	<ul id="nav-breadcrumbs" class="linklist navlinks" role="menubar">
						<li class="small-icon icon-home breadcrumbs">
			<span class="crumb" itemtype="http://data-vocabulary.org/Breadcrumb" itemscope=""><a href="http://www.scarleteen.com" data-navbar-reference="home" itemprop="url"><span itemprop="title">Home</span></a></span>						<span class="crumb" itemtype="http://data-vocabulary.org/Breadcrumb" itemscope=""><a href="./index.php" accesskey="h" data-navbar-reference="index" itemprop="url"><span itemprop="title">Board index</span></a></span>
								</li>
		
					<li class="rightside responsive-search" style="display: none;"><a href="./search.php" title="View the advanced search options" role="menuitem">Search</a></li>
			</ul>

	</div>
</div>
		<div class="headerbar" role="banner">
			<div class="inner">

			<div id="archive-link">
				<a href="http://www.scarleteen.com/forum/ultimatebb.php" title="View the Archived Boards" target="_blank">View Archives (Old Boards)</a> |
				<a href="http://www.scarleteen.com/search/google">Search full site</a>
			</div>

			</div>
		</div>
	</div>

	
	<a id="start_here" class="anchor"></a>
	<div id="page-body" role="main">
		
		
<p class="right responsive-center time">It is currently Tue Jan 14, 2020 8:26 pm</p>

	<div class="action-bar compact">
		<a href="./index.php?hash=58dd4a33&amp;mark=forums&amp;mark_time=1579058783" class="mark-read rightside" accesskey="m" data-ajax="mark_forums_read">Mark forums read</a>
	</div>


	
				<div class="forabg">
			<div class="inner">
			<ul class="topiclist">
				<li class="header">
										<dl class="icon">
						<dt><div class="list-inner"><a href="./viewforum.php?f=4">Between you and the Scarleteam (user-to-staff discussion ONLY)</a></div></dt>
						<dd class="topics">Topics</dd>
						<dd class="posts">Posts</dd>
						<dd class="lastpost"><span>Last post</span></dd>
					</dl>
									</li>
			</ul>
			<ul class="topiclist forums">
		
	
	
	
			
					<li class="row">
						<dl class="icon forum_unread">
				<dt title="Unread posts">
					<a href="./viewforum.php?f=5" class="icon-link"></a>					<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Ask Us!" href="https://www.scarleteen.com/bb/feed.php?f=5"><img src="./styles/scarleteen/theme/images/feed.gif" alt="Feed - Ask Us!" /></a> -->
												<a href="./viewforum.php?f=5" class="forumtitle">Ask Us!</a>
						<br />Any questions or discussions that you ONLY want to discuss with our staff or volunteers. <br /><strong>(Users: please do not reply to other users here.)</strong>												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>3848</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">3848 <dfn>Topics</dfn></dd>
					<dd class="posts">18339 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=5&amp;p=48745#p48745" title="Re: People on Testosterone: Is Erectile Dysfunction possible?" class="lastsubject">Re: People on Testosterone: I…</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=6854" class="username">BuddyBoi21</a>
						<a href="./viewtopic.php?f=5&amp;p=48745#p48745"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Tue Jan 14, 2020 6:40 pm</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_unread">
				<dt title="Unread posts">
					<a href="./viewforum.php?f=3" class="icon-link"></a>					<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Scarleteen Updates" href="https://www.scarleteen.com/bb/feed.php?f=3"><img src="./styles/scarleteen/theme/images/feed.gif" alt="Feed - Scarleteen Updates" /></a> -->
												<a href="./viewforum.php?f=3" class="forumtitle">Scarleteen Updates</a>
						<br />Site or organizational updates, like new content, tools or services, activist alerts, news or other Scarleteen-related information.												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>268</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">268 <dfn>Topics</dfn></dd>
					<dd class="posts">313 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=3&amp;p=48697#p48697" title="Getting Birth Control May Be Easier Than You Think!" class="lastsubject">Getting Birth Control May Be …</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=52" style="color: #CC0066;" class="username-coloured">Sam W</a>
						<a href="./viewtopic.php?f=3&amp;p=48697#p48697"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Mon Jan 13, 2020 11:34 am</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_unread">
				<dt title="Unread posts">
					<a href="./viewforum.php?f=2" class="icon-link"></a>					<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Site Help &amp; Service" href="https://www.scarleteen.com/bb/feed.php?f=2"><img src="./styles/scarleteen/theme/images/feed.gif" alt="Feed - Site Help &amp; Service" /></a> -->
												<a href="./viewforum.php?f=2" class="forumtitle">Site Help &amp; Service</a>
						<br />Board FAQs, help and general announcements about the boards for users.												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>52</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">52 <dfn>Topics</dfn></dd>
					<dd class="posts">146 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=2&amp;p=48744#p48744" title="Re: Live Chat Requests/Change in Live Chat" class="lastsubject">Re: Live Chat Requests/Change…</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=9744" class="username">bluestarfish</a>
						<a href="./viewtopic.php?f=2&amp;p=48744#p48744"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Tue Jan 14, 2020 6:09 pm</span>
					</dd>
							</dl>
					</li>
			
	
				</ul>

			</div>
		</div>
	
				<div class="forabg">
			<div class="inner">
			<ul class="topiclist">
				<li class="header">
										<dl class="icon">
						<dt><div class="list-inner"><a href="./viewforum.php?f=18">Newbieville (moderated user-to-user or user-to-staff discusssion for new users)</a></div></dt>
						<dd class="topics">Topics</dd>
						<dd class="posts">Posts</dd>
						<dd class="lastpost"><span>Last post</span></dd>
					</dl>
									</li>
			</ul>
			<ul class="topiclist forums">
		
	
	
	
			
					<li class="row">
						<dl class="icon forum_unread">
				<dt title="Unread posts">
					<a href="./viewforum.php?f=21" class="icon-link"></a>					<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Got Questions? Get Answers." href="https://www.scarleteen.com/bb/feed.php?f=21"><img src="./styles/scarleteen/theme/images/feed.gif" alt="Feed - Got Questions? Get Answers." /></a> -->
												<a href="./viewforum.php?f=21" class="forumtitle">Got Questions? Get Answers.</a>
						<br />Brand-new? This is the place for your questions and discussions on any and all topics, with fellow users or staff, while you get your feet wet.												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>899</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">899 <dfn>Topics</dfn></dd>
					<dd class="posts">4747 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=21&amp;p=48743#p48743" title="Re: Transgender? (Mtf)" class="lastsubject">Re: Transgender? (Mtf)</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=9728" class="username">CaptainWildRose</a>
						<a href="./viewtopic.php?f=21&amp;p=48743#p48743"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Tue Jan 14, 2020 5:51 pm</span>
					</dd>
							</dl>
					</li>
			
	
				</ul>

			</div>
		</div>
	
				<div class="forabg">
			<div class="inner">
			<ul class="topiclist">
				<li class="header">
										<dl class="icon">
						<dt><div class="list-inner"><a href="./viewforum.php?f=7">All the things (moderated user-to-user or user-to-staff discussion)</a></div></dt>
						<dd class="topics">Topics</dd>
						<dd class="posts">Posts</dd>
						<dd class="lastpost"><span>Last post</span></dd>
					</dl>
									</li>
			</ul>
			<ul class="topiclist forums">
		
	
	
	
			
					<li class="row">
						<dl class="icon forum_unread">
				<dt title="Unread posts">
					<a href="./viewforum.php?f=9" class="icon-link"></a>					<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Bodies" href="https://www.scarleteen.com/bb/feed.php?f=9"><img src="./styles/scarleteen/theme/images/feed.gif" alt="Feed - Bodies" /></a> -->
												<a href="./viewforum.php?f=9" class="forumtitle">Bodies</a>
						<br />Questions and discussions about your bodies and their parts.												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>275</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">275 <dfn>Topics</dfn></dd>
					<dd class="posts">1462 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=9&amp;p=48731#p48731" title="Re: Questions about my labia" class="lastsubject">Re: Questions about my labia</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=52" style="color: #CC0066;" class="username-coloured">Sam W</a>
						<a href="./viewtopic.php?f=9&amp;p=48731#p48731"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Tue Jan 14, 2020 9:06 am</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_unread">
				<dt title="Unread posts">
					<a href="./viewforum.php?f=11" class="icon-link"></a>					<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Gender" href="https://www.scarleteen.com/bb/feed.php?f=11"><img src="./styles/scarleteen/theme/images/feed.gif" alt="Feed - Gender" /></a> -->
												<a href="./viewforum.php?f=11" class="forumtitle">Gender</a>
						<br />Questions and discussions about gender, gender roles and identity.												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>93</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">93 <dfn>Topics</dfn></dd>
					<dd class="posts">624 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=11&amp;p=48715#p48715" title="Re: How has your gender expression evolved?" class="lastsubject">Re: How has your gender expre…</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=3592" class="username">bikinksterboy</a>
						<a href="./viewtopic.php?f=11&amp;p=48715#p48715"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Tue Jan 14, 2020 12:50 am</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_unread">
				<dt title="Unread posts">
					<a href="./viewforum.php?f=15" class="icon-link"></a>					<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Sexual Identity" href="https://www.scarleteen.com/bb/feed.php?f=15"><img src="./styles/scarleteen/theme/images/feed.gif" alt="Feed - Sexual Identity" /></a> -->
												<a href="./viewforum.php?f=15" class="forumtitle">Sexual Identity</a>
						<br />Questions and discussion about your sexuality and how it's a part of who you are as a person.												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>113</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">113 <dfn>Topics</dfn></dd>
					<dd class="posts">954 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=15&amp;p=48717#p48717" title="Re: If You're Celebrating Pride, How are You Celebrating It?" class="lastsubject">Re: If You're Celebrating Pri…</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=3592" class="username">bikinksterboy</a>
						<a href="./viewtopic.php?f=15&amp;p=48717#p48717"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Tue Jan 14, 2020 12:59 am</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_unread">
				<dt title="Unread posts">
					<a href="./viewforum.php?f=14" class="icon-link"></a>					<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Relationships" href="https://www.scarleteen.com/bb/feed.php?f=14"><img src="./styles/scarleteen/theme/images/feed.gif" alt="Feed - Relationships" /></a> -->
												<a href="./viewforum.php?f=14" class="forumtitle">Relationships</a>
						<br />Questions and discussions about relationships: girlfriends, boyfriends, lovers, partners, friends, family or other intimate relationships in your lives.												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>504</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">504 <dfn>Topics</dfn></dd>
					<dd class="posts">3607 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=14&amp;p=48737#p48737" title="Re: Why is love so hard???" class="lastsubject">Re: Why is love so hard???</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=49" style="color: #990000;" class="username-coloured">Heather</a>
						<a href="./viewtopic.php?f=14&amp;p=48737#p48737"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Tue Jan 14, 2020 9:56 am</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_unread">
				<dt title="Unread posts">
					<a href="./viewforum.php?f=13" class="icon-link"></a>					<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Sex &amp; Sexuality" href="https://www.scarleteen.com/bb/feed.php?f=13"><img src="./styles/scarleteen/theme/images/feed.gif" alt="Feed - Sex &amp; Sexuality" /></a> -->
												<a href="./viewforum.php?f=13" class="forumtitle">Sex &amp; Sexuality</a>
						<br />Questions and discussion about your sexual lives, choices, activities, ideas and experiences.												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>492</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">492 <dfn>Topics</dfn></dd>
					<dd class="posts">2585 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=13&amp;p=48730#p48730" title="Re: normal sexual thoughts or not?" class="lastsubject">Re: normal sexual thoughts or…</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=52" style="color: #CC0066;" class="username-coloured">Sam W</a>
						<a href="./viewtopic.php?f=13&amp;p=48730#p48730"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Tue Jan 14, 2020 8:51 am</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_unread">
				<dt title="Unread posts">
					<a href="./viewforum.php?f=10" class="icon-link"></a>					<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Sexual Health" href="https://www.scarleteen.com/bb/feed.php?f=10"><img src="./styles/scarleteen/theme/images/feed.gif" alt="Feed - Sexual Health" /></a> -->
												<a href="./viewforum.php?f=10" class="forumtitle">Sexual Health</a>
						<br />Questions and discussion about contraception, safer sex, STIs, sexual healthcare and other sexual health issues.												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>416</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">416 <dfn>Topics</dfn></dd>
					<dd class="posts">2071 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=10&amp;p=48615#p48615" title="Re: I went to the doctor today" class="lastsubject">Re: I went to the doctor today</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=65" style="color: #CC0066;" class="username-coloured">Mo</a>
						<a href="./viewtopic.php?f=10&amp;p=48615#p48615"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Tue Jan 07, 2020 3:57 pm</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_unread">
				<dt title="Unread posts">
					<a href="./viewforum.php?f=12" class="icon-link"></a>					<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Pregnancy and Parenting" href="https://www.scarleteen.com/bb/feed.php?f=12"><img src="./styles/scarleteen/theme/images/feed.gif" alt="Feed - Pregnancy and Parenting" /></a> -->
												<a href="./viewforum.php?f=12" class="forumtitle">Pregnancy and Parenting</a>
						<br />Questions and discussion for those who are or have been pregnant (or have pregnant partners), parenting or about options with an unintended pregnancy. <br /><strong>No pregnancy scare posts here, please.</strong>												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>43</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">43 <dfn>Topics</dfn></dd>
					<dd class="posts">168 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=12&amp;p=48733#p48733" title="Re: update on my post-abortion" class="lastsubject">Re: update on my post-abortion</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=49" style="color: #990000;" class="username-coloured">Heather</a>
						<a href="./viewtopic.php?f=12&amp;p=48733#p48733"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Tue Jan 14, 2020 9:24 am</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_unread">
				<dt title="Unread posts">
					<a href="./viewforum.php?f=16" class="icon-link"></a>					<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Abuse &amp; Assault" href="https://www.scarleteen.com/bb/feed.php?f=16"><img src="./styles/scarleteen/theme/images/feed.gif" alt="Feed - Abuse &amp; Assault" /></a> -->
												<a href="./viewforum.php?f=16" class="forumtitle">Abuse &amp; Assault</a>
						<br />Questions and discussion about sexual or other abuse or assault, and support and help for survivors.												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>165</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">165 <dfn>Topics</dfn></dd>
					<dd class="posts">1644 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=16&amp;p=48736#p48736" title="Re: Would you call this sexual abuse?" class="lastsubject">Re: Would you call this sexua…</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=49" style="color: #990000;" class="username-coloured">Heather</a>
						<a href="./viewtopic.php?f=16&amp;p=48736#p48736"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Tue Jan 14, 2020 9:50 am</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_unread">
				<dt title="Unread posts">
					<a href="./viewforum.php?f=17" class="icon-link"></a>					<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Sex, Culture and Politics" href="https://www.scarleteen.com/bb/feed.php?f=17"><img src="./styles/scarleteen/theme/images/feed.gif" alt="Feed - Sex, Culture and Politics" /></a> -->
												<a href="./viewforum.php?f=17" class="forumtitle">Sex, Culture and Politics</a>
						<br />Questions and discussion about sex and sexuality in political or community beliefs, principles, actions, policies, experiences, messages and media.												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>112</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">112 <dfn>Topics</dfn></dd>
					<dd class="posts">532 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=17&amp;p=47245#p47245" title="Re: The Sex Talk" class="lastsubject">Re: The Sex Talk</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=8790" class="username">RadiantRay</a>
						<a href="./viewtopic.php?f=17&amp;p=47245#p47245"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Tue Oct 15, 2019 4:26 pm</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_unread">
				<dt title="Unread posts">
					<a href="./viewforum.php?f=25" class="icon-link"></a>					<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Supporting Each Other" href="https://www.scarleteen.com/bb/feed.php?f=25"><img src="./styles/scarleteen/theme/images/feed.gif" alt="Feed - Supporting Each Other" /></a> -->
												<a href="./viewforum.php?f=25" class="forumtitle">Supporting Each Other</a>
						<br />When you want support through something scary or rough, and help pulling yourself together and getting through, this is the place.												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>120</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">120 <dfn>Topics</dfn></dd>
					<dd class="posts">1001 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=25&amp;p=48107#p48107" title="Re: If the Holidays are a Tough Time for You, What are some things you're doing for self-care?" class="lastsubject">Re: If the Holidays are a Tou…</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=8746" class="username">SpaceCowboy</a>
						<a href="./viewtopic.php?f=25&amp;p=48107#p48107"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Tue Dec 03, 2019 1:38 pm</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_unread">
				<dt title="Unread posts">
					<a href="./viewforum.php?f=19" class="icon-link"></a>					<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Et Cetera" href="https://www.scarleteen.com/bb/feed.php?f=19"><img src="./styles/scarleteen/theme/images/feed.gif" alt="Feed - Et Cetera" /></a> -->
												<a href="./viewforum.php?f=19" class="forumtitle">Et Cetera</a>
						<br />If it doesn't seem to fit anywhere else, this is probably the place for it.												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>172</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">172 <dfn>Topics</dfn></dd>
					<dd class="posts">1024 <dfn>Posts</dfn></dd>
					<dd class="lastpost"><span>
												<dfn>Last post</dfn>
																				<a href="./viewtopic.php?f=19&amp;p=48716#p48716" title="Re: What is one thing you learned about sex &amp; yourself this year?" class="lastsubject">Re: What is one thing you lea…</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=3592" class="username">bikinksterboy</a>
						<a href="./viewtopic.php?f=19&amp;p=48716#p48716"><span class="imageset icon_topic_latest" title="View the latest post">View the latest post</span></a> <br />Tue Jan 14, 2020 12:55 am</span>
					</dd>
							</dl>
					</li>
			
				</ul>

			</div>
		</div>
		


	<form method="post" action="./ucp.php?mode=login" class="headerspace">
	<h3><a href="./ucp.php?mode=login">Login</a>&nbsp; &bull; &nbsp;<a href="./ucp.php?mode=register">Register</a></h3>
		<fieldset class="quick-login">
			<label for="username"><span>Username:</span> <input type="text" tabindex="1" name="username" id="username" size="10" class="inputbox" title="Username" /></label>
			<label for="password"><span>Password:</span> <input type="password" tabindex="2" name="password" id="password" size="10" class="inputbox" title="Password" autocomplete="off" /></label>
							<a href="./ucp.php?mode=sendpassword">I forgot my password</a>
										<span class="responsive-hide">|</span> <label for="autologin">Remember me <input type="checkbox" tabindex="4" name="autologin" id="autologin" /></label>
						<input type="submit" tabindex="5" name="login" value="Login" class="button2" />
			<input type="hidden" name="redirect" value="./index.php?" />

		</fieldset>
	</form>


	<div class="stat-block online-list">
		<h3>Who is online</h3>		<p>
						In total there are <strong>48</strong> users online :: 3 registered, 0 hidden and 45 guests (based on users active over the past 5 minutes)<br />Most users ever online was <strong>2951</strong> on Thu Nov 14, 2019 7:09 am<br /> <br />Registered users: <span style="color: #9E8DA7;" class="username-coloured">Bing [Bot]</span>, <span style="color: #9E8DA7;" class="username-coloured">Google [Bot]</span>, <a href="./memberlist.php?mode=viewprofile&amp;u=8984" class="username">horriblegoose</a>
			<br /><em>Legend: <a style="color:#990000" href="./memberlist.php?mode=group&amp;g=5">Administrators</a>, <a style="color:#CC0066" href="./memberlist.php?mode=group&amp;g=8">Staff &amp; Volunteers</a>, <a style="color:#9966CC" href="./memberlist.php?mode=group&amp;g=9">Volunteers in Training</a>, <a style="color:#FF8000" href="./memberlist.php?mode=group&amp;g=16">New Volunteers in Training</a></em>					</p>
	</div>

	<div class="stat-block birthday-list">
		<h3>Birthdays</h3>
		<p>
						No birthdays today					</p>
	</div>

	<div class="stat-block statistics">
		<h3>Statistics</h3>
		<p>
						Total posts <strong>46687</strong> &bull; Total topics <strong>8614</strong> &bull; Total members <strong>6853</strong> &bull; Our newest member <strong><a href="./memberlist.php?mode=viewprofile&amp;u=9755" class="username">SamanthaXYZ</a></strong>
					</p>
	</div>


			</div>


<div class="navbar" role="navigation">
	<div class="inner">

		<ul id="nav-footer" class="linklist bulletin" role="menubar">
			<li class="small-icon icon-home breadcrumbs">
				<span class="crumb"><a href="http://www.scarleteen.com" data-navbar-reference="home">Home</a></span>								<span class="crumb"><a href="./index.php" data-navbar-reference="index">Board index</a></span>
							</li>
			
						<li class="rightside">All times are <abbr title="UTC-7">UTC-07:00</abbr></li>
										<li class="small-icon icon-delete-cookies rightside"><a href="./ucp.php?mode=delete_cookies" data-ajax="true" data-refresh="true" role="menuitem">Delete all board cookies</a></li>
													<li class="small-icon icon-team rightside" data-last-responsive="true"><a href="./memberlist.php?mode=team" role="menuitem">The team</a></li>								</ul>

	</div>
</div>

<div id="page-footer" role="contentinfo">

	
    <footer id="footer" class="footer container-fluid">
      <div id="footer-widgets">
      <h4>and so very much more</h4>
      <div class="region-footer-widgets" id="footer-widgets-content">
          <div class="region region-footer-widgets-1">
    <section id="block-tagclouds-3" class="block block-tagclouds clearfix"
>

        <h2 aria-level="3"  class="block-title"><span data-toggle="collapse"
         data-target="#block-tagclouds-3_content"
         data-parent="#footer-widgets"
         aria-expanded="false"
         aria-controls="block-tagclouds-3_content">
         more topics<span class="colon">:</span><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></span></h2>
    
  <div class="block-content collapse" id="block-tagclouds-3_content">
    <span class='tagclouds-term'><a href="/tags/abuse" class="tagclouds level1" title="">abuse</a></span>
<span class='tagclouds-term'><a href="/tags/activism" class="tagclouds level1" title="">activism</a></span>
<span class='tagclouds-term'><a href="/tags/birth_control" class="tagclouds level2" title="">birth control</a></span>
<span class='tagclouds-term'><a href="/tags/bodies" class="tagclouds level3" title="">bodies</a></span>
<span class='tagclouds-term'><a href="/tags/body" class="tagclouds level1" title="">body</a></span>
<span class='tagclouds-term'><a href="/tags/body_image" class="tagclouds level1" title="">body image</a></span>
<span class='tagclouds-term'><a href="/tags/boundaries" class="tagclouds level1" title="">boundaries</a></span>
<span class='tagclouds-term'><a href="/tags/choices" class="tagclouds level4" title="">choices</a></span>
<span class='tagclouds-term'><a href="/tags/communication" class="tagclouds level4" title="">communication</a></span>
<span class='tagclouds-term'><a href="/tags/condoms" class="tagclouds level1" title="">condoms</a></span>
<span class='tagclouds-term'><a href="/tags/consent" class="tagclouds level1" title="">consent</a></span>
<span class='tagclouds-term'><a href="/tags/culture" class="tagclouds level1" title="">culture</a></span>
<span class='tagclouds-term'><a href="/tags/feelings" class="tagclouds level1" title="">feelings</a></span>
<span class='tagclouds-term'><a href="/tags/gender" class="tagclouds level2" title="">gender</a></span>
<span class='tagclouds-term'><a href="/tags/health" class="tagclouds level2" title="">health</a></span>
<span class='tagclouds-term'><a href="/tags/healthy" class="tagclouds level1" title="">healthy</a></span>
<span class='tagclouds-term'><a href="/tags/help" class="tagclouds level2" title="">help</a></span>
<span class='tagclouds-term'><a href="/tags/identity" class="tagclouds level3" title="">identity</a></span>
<span class='tagclouds-term'><a href="/tags/intercourse" class="tagclouds level1" title="">intercourse</a></span>
<span class='tagclouds-term'><a href="/tags/love" class="tagclouds level3" title="">love</a></span>
<span class='tagclouds-term'><a href="/tags/men" class="tagclouds level3" title="">men</a></span>
<span class='tagclouds-term'><a href="/tags/partner" class="tagclouds level3" title="">partner</a></span>
<span class='tagclouds-term'><a href="/tags/pleasure" class="tagclouds level3" title="">pleasure</a></span>
<span class='tagclouds-term'><a href="/tags/politics" class="tagclouds level2" title="">politics</a></span>
<span class='tagclouds-term'><a href="/tags/pregnancy" class="tagclouds level2" title="">pregnancy</a></span>
<span class='tagclouds-term'><a href="/tags/readiness" class="tagclouds level2" title="">readiness</a></span>
<span class='tagclouds-term'><a href="/tags/relationships" class="tagclouds level6" title="">relationships</a></span>
<span class='tagclouds-term'><a href="/tags/respect" class="tagclouds level1" title="">respect</a></span>
<span class='tagclouds-term'><a href="/tags/risk" class="tagclouds level2" title="">risk</a></span>
<span class='tagclouds-term'><a href="/tags/safer_sex" class="tagclouds level1" title="">safer sex</a></span>
<span class='tagclouds-term'><a href="/tags/safety" class="tagclouds level2" title="">safety</a></span>
<span class='tagclouds-term'><a href="/tags/self_esteem" class="tagclouds level1" title="">self-esteem</a></span>
<span class='tagclouds-term'><a href="/tags/sex" class="tagclouds level6" title="">sex</a></span>
<span class='tagclouds-term'><a href="/tags/sex_education" class="tagclouds level1" title="">sex education</a></span>
<span class='tagclouds-term'><a href="/tags/sexual_health" class="tagclouds level3" title="">sexual health</a></span>
<span class='tagclouds-term'><a href="/tags/sexuality" class="tagclouds level6" title="">sexuality</a></span>
<span class='tagclouds-term'><a href="/tags/sti" class="tagclouds level1" title="">sti</a></span>
<span class='tagclouds-term'><a href="/tags/support" class="tagclouds level3" title="">support</a></span>
<span class='tagclouds-term'><a href="/tags/teen" class="tagclouds level2" title="">teen</a></span>
<span class='tagclouds-term'><a href="/tags/women" class="tagclouds level4" title="">women</a></span>

    <div class="more-link"><a href="/tagcloud" title="more tags">More</a></div>
  </div>

</section>
  </div>
          <div class="region region-footer-widgets-2">
    <section id="block-menu-menu-extra-extra" class="block block-menu clearfix"aria-level="3">

        <h2 class="block-title"><span data-toggle="collapse"
         data-target="#block-menu-menu-extra-extra_content"
         data-parent="#footer-widgets"
         aria-expanded="false"
         aria-controls="block-menu-menu-extra-extra_content">
         extra, extra<span class="colon">:</span><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></span></h2>
    
  <div class="block-content collapse" id="block-menu-menu-extra-extra_content">
    <ul class="menu nav"><li class="first leaf" id="menu-blog"><a href="/blog">our blog</a></li>
<li class="leaf" id="menu-6557"><a href="/need_help_now_a_guide_to_scarleteens_direct_services" title="a guide to using our direct services">our direct services how-to</a></li>
<li class="leaf" id="menu-condom_shop"><a href="/condom_shop">the safer sex shop</a></li>
<li class="leaf" id="menu-225"><a href="/article/read/all_about_s_e_x_the_scarleteen_book" title="find out about or get our book!">s.e.x.: the scarleteen book</a></li>
<li class="leaf" id="menu-scarleteen.threadless.com"><a href="https://scarleteen.threadless.com/">Scarleteen on Threadless!</a></li>
<li class="leaf" id="menu-scarleteen_confidential"><a href="http://www.scarleteen.com/tags/scarleteen_confidential">scarleteen confidential </a></li>
<li class="leaf" id="menu-scarleteenorg"><a href="https://www.instagram.com/scarleteenorg/">follow our instagram</a></li>
<li class="leaf" id="menu-hellyeahscarleteen.tumblr.com"><a href="http://hellyeahscarleteen.tumblr.com/" title="Scarleteen&#039;s tumblr feed">follow our tumblr</a></li>
<li class="leaf" id="menu-Scarleteen"><a href="https://twitter.com/Scarleteen" title="Our twitter feed">follow us on twitter</a></li>
<li class="last leaf" id="menu-15025045594"><a href="https://www.facebook.com/pages/Scarleteen/15025045594" title="Our Facebook page">like us (or not) on facebook</a></li>
</ul>  </div>

</section>
  </div>
          <div class="region region-footer-widgets-3">
    <section id="block-menu-menu-the-abouts" class="block block-menu clearfix">

        <h2 class="block-title"><span data-toggle="collapse"
         data-target="#block-menu-menu-the-abouts_content"
         data-parent="#footer-widgets"
         aria-expanded="false"
         aria-controls="block-menu-menu-the-abouts_content">
         the abouts<span class="colon">:</span><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></span></h2>
    
  <div class="block-content collapse" id="block-menu-menu-the-abouts_content">
    <ul class="menu nav"><li class="first collapsed" id="menu-241"><a href="/user_guidelines_privacy_policy" title="">guidelines &amp; policies</a></li>
<li class="leaf" id="menu-556"><a href="/the_scarleteen_staff_volunteers" title="who the heck we are">our staff and volunteers</a></li>
<li class="collapsed" id="menu-220"><a href="/about_scarleteen" title="">all about scarleteen</a></li>
<li class="leaf" id="menu-2296"><a href="/scarleteen_volunteer_application" title="apply to volunteer at Scarleteen">volunteer application</a></li>
<li class="leaf" id="menu-223"><a href="/for_parents_and_guardians">for parents or guardians</a></li>
<li class="leaf" id="menu-1433116?code=STPRIMARY"><a href="https://donatenow.networkforgood.org/1433116?code=STPRIMARY" title="donate now">help support scarleteen</a></li>
<li class="leaf" id="menu-contact"><a href="/contact" title="email form">contact us</a></li>
<li class="leaf" id="menu-www.scarleteen.com"><a href="http://www.scarleteen.com">just go home, already.</a></li>
<li class="last leaf" id="menu-login"><a href="/user/login">staff &amp; volunteer login</a></li>
</ul>  </div>

</section>
  </div>
      </div>
    </div>
  
  <div class="footer-donation">
    <a href="https://npo.networkforgood.org/Donate/Donate.aspx?npoSubscriptionId=1005181&amp;code=STPRIMARY"><img alt="Donate Here" src="/sites/all/themes/scarleteen/images/donation.png" title="Donate Now - help keep the best sex ed online free and also fabulous"></a>
  </div>

    <div class="region region-footer">
    <section id="block-block-46" class="block block-block letters clearfix"

>

      
  <div class="block-content">
     <p><img alt="We love L, G, B, T, Q, A and all the letters" src="/sites/files/scarleteen/images/allTheLetters.jpg" title="all the letters" /></p>
   </div>

</section>
<section id="block-block-38" class="block block-block clearfix"

>

      
  <div class="block-content">
     <p><em>Information on this site is provided for educational purposes. It is not meant to and cannot substitute for advice or care provided by an in-person medical professional. The information contained herein is not meant to be used to diagnose or treat a health problem or disease, or for prescribing any medication. You should always consult your own <a href="https://www.scarleteen.com/glossary#healthcare_provider" title="A qualified person to provide sound physical and/or mental healthcare, such as a doctor, nurse, clinician, counselor, medical assistant, midwife or other healthcare professional." class="lexicon-term">healthcare provider</a> if you have a health problem or medical condition.</em></p>
   </div>

</section>
<section id="block-block-45" class="block block-block clearfix"

>

      
  <div class="block-content">
    <p>© 1998 - 2020 Scarleteen/Heather Corinna. All Rights Reserved. | <a href="/user_guidelines_privacy_policy">Privacy Policy &amp; User Guidelines</a></p>
  </div>

</section>
  </div>
</footer>
  

				
	<div id="darkenwrapper" data-ajax-error-title="AJAX error" data-ajax-error-text="Something went wrong when processing your request." data-ajax-error-text-abort="User aborted request." data-ajax-error-text-timeout="Your request timed out; please try again." data-ajax-error-text-parsererror="Something went wrong with the request and the server returned an invalid reply.">
		<div id="darken">&nbsp;</div>
	</div>

	<div id="phpbb_alert" class="phpbb_alert" data-l-err="Error" data-l-timeout-processing-req="Request timed out.">
		<a href="#" class="alert_close"></a>
		<h3 class="alert_title">&nbsp;</h3><p class="alert_text"></p>
	</div>
	<div id="phpbb_confirm" class="phpbb_alert">
		<a href="#" class="alert_close"></a>
		<div class="alert_text"></div>
	</div>
</div>

</div>

<div>
	<a id="bottom" class="anchor" accesskey="z"></a>
	</div>

<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script type="text/javascript">window.jQuery || document.write(unescape('%3Cscript src="./assets/javascript/jquery.min.js?assets_version=21" type="text/javascript"%3E%3C/script%3E'));</script><script type="text/javascript" src="./assets/javascript/core.js?assets_version=21"></script>

<script type="text/javascript" src="https://www.scarleteen.com/sites/all/themes/scarleteen/bootstrap/js/transition.js"></script>
<script type="text/javascript" src="https://www.scarleteen.com/sites/all/themes/scarleteen/bootstrap/js/collapse.js"></script>
<script type="text/javascript" src="https://www.scarleteen.com/bb/styles/scarleteen/template/script.js"></script>

<script>
	(function() {
		var cx = '012715433979959066630\x3Aqzno9cthz0c';
		var gcse = document.createElement('script');
		gcse.type = 'text/javascript';
		gcse.async = true;
		gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
			'//cse.google.com/cse.js?cx=' + cx;
		var s = document.getElementsByTagName('script')[0];
		s.parentNode.insertBefore(gcse, s);
	})();
</script><script type="text/javascript">
(function($) {  // Avoid conflicts with other libraries

'use strict';
	
	phpbb.addAjaxCallback('reporttosfs', function(data) {
		if (data.postid !== "undefined") {
			$('#sfs' + data.postid).hide();
			phpbb.closeDarkenWrapper(5000);
		}
	});

})(jQuery);
</script>
<script type="text/javascript" src="./styles/prosilver/template/forum_fn.js?assets_version=21"></script>

<script type="text/javascript" src="./styles/prosilver/template/ajax.js?assets_version=21"></script>




<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-78460470-3', 'auto');
  ga('send', 'pageview');

</script>

</body>
</html>
